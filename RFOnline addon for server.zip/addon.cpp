#include "stdafx.h"

#include "addon.h"
#include "../../Common/ETypes.h"
#include "../../Common/Helpers/RapidHelper.hpp"

#include <ATF/global.hpp>

namespace GameServer
{
    namespace Addon
    {
        void CAddon::load()
        {
            // todo
        }

        void CAddon::unload()
        {
            cleanup_all_hook();
        }

        Yorozuya::Module::ModuleName_t CAddon::get_name()
        {
            static const Yorozuya::Module::ModuleName_t name = "<todo>";
            return name;
        }

        void CAddon::configure(const rapidjson::Value & nodeConfig)
        {
            // todo
        }
    }
}
